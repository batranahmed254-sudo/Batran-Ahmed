# SAVANNA BREW CAFE WEBSITE

BATRAN ABDIKARIM
Reg No 23/02332

## 1. Project Description
Savanna Brew Cafe  is a fictional Cafe website based in Nairobi, Kenya. The website was developed to provide visitors with information about the café, its background, menu, gallery and contact details.

## 2. Website Pages
The website contains five HTML pages:

- **index.html** – Homepage introducing Savanna Brew Cafe.
- **about.html** – Information about the cafe and its owner.
- **menu.html** – Displays the Cafe's food and drink menu with prices.
- **gallery.html** – Displays eight photographs showing the cafe's pastries, display window, window seats, barista at work, morning crowd, iced drinks, warm interior and coffee beans.
- **contact.html** – Contains the cafe's contact information and reservation form.

## 3. Technologies Used
The website was developed using:
- HTML5 – For the structure and content of the website.
- CSS3 – For styling, colours, layouts and responsiveness.

## 4. Project Folder Structure
The project contains the following folders and files:

- HTML files for the five website pages.
- `css/style.css` – The external stylesheet used throughout the website.
- `images/` – Contains the cafe logo and photographs used on the website.

## 5. Design and Colour Scheme
The website uses a coffee-inspired colour scheme:

- Coffee Brown: #6F4E37
- Cream: #F5E9DA
- Orange: #D9822B
- Dark Brown: #2B1B12
- White: #FFFFFF

The website uses Flexbox and CSS Grid for layout and includes responsive styling for smaller screens.

## 6. How to View the Website
1. Extract the ZIP folder.
2. Open the project folder.
3. Locate `index.html`.
4. Double-click `index.html` to open the website in a web browser.

## 7. Additional Notes
Savanna Brew Cafe is a fictional business created for academic purposes. The reservation form is a demonstration form and does not store or process actual bookings.